setwd("C:\\Users\\Randini\\Desktop\\IT24100974")
getwd()

set.seed(123)  # Ensures reproducibility
sample_times <- rnorm(25, mean = 45, sd = 2)
print("Random Sample of Baking Times:")
print(sample_times)

# Part (ii) Hypothesis Test
# H0: mu = 46, H1: mu < 46
t_test_result <- t.test(sample_times, mu = 46, alternative = "less")
print("One-sample t-test result:")
print(t_test_result)

